create view v_comp as
  select `gfo_sa`.`company`.`company_name`         AS `company_name`,
         `gfo_sa`.`company`.`contacts`             AS `contacts`,
         `gfo_sa`.`company`.`contact_number`       AS `contact_number`,
         `gfo_sa`.`datainformation`.`product_name` AS `product_name`,
         `gfo_sa`.`company`.`address`              AS `address`
  from (`gfo_sa`.`company` join `gfo_sa`.`datainformation` on ((`gfo_sa`.`company`.`id` =
                                                                `gfo_sa`.`datainformation`.`company_id`)))
  where ((`gfo_sa`.`datainformation`.`type_fill` = 1) and (`gfo_sa`.`datainformation`.`type` = 1));

