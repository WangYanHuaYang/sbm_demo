create view v_cd as
  select `c`.`company_name`       AS `company_name`,
         `c`.`legal_person`       AS `legal_person`,
         `r1`.`region_name`       AS `city`,
         `r2`.`region_name`       AS `area`,
         `c`.`address`            AS `address`,
         `c`.`telephone`          AS `telephone`,
         `c`.`mobile_phone`       AS `mobile_phone`,
         `c`.`contacts`           AS `contacts`,
         `c`.`contact_number`     AS `contact_number`,
         `c`.`postal_code`        AS `postal_code`,
         `c`.`enterprise_number`  AS `enterprise_number`,
         `d`.`product_name`       AS `product_name`,
         `d`.`internal_inspector` AS `internal_inspector`,
         `d`.`internal_tel`       AS `internal_tel`,
         `p1`.`category_name`     AS `crop_type`,
         `p2`.`category_name`     AS `type_category`,
         `d`.`trademark`          AS `trademark`,
         `d`.`certificate_number` AS `certificate_number`,
         `d`.`plant_scale`        AS `plant_scale`,
         `d`.`breed_scale`        AS `breed_scale`,
         `d`.`yield`              AS `yield`,
         `d`.`output_value`       AS `output_value`,
         `d`.`sales_volume`       AS `sales_volume`,
         `d`.`exit_amount`        AS `exit_amount`,
         `d`.`exit_forehead`      AS `exit_forehead`,
         `d`.`effective_time`     AS `effective_time`,
         `d`.`Invalid_time`       AS `Invalid_time`,
         `d`.`enterprise_type`    AS `enterprise_type`,
         `d`.`declaration_type`   AS `declaration_type`,
         `d`.`base_type`          AS `base_type`,
         `c`.`profit`             AS `profit`,
         `c`.`gross_production`   AS `gross_production`,
         `c`.`enterprise_type`    AS `enterprise_type2`,
         `c`.`cooperative`        AS `cooperative`,
         `c`.`familyfarm`         AS `familyfarm`,
         `c`.`postal_code2`       AS `postal_code2`,
         `c`.`post_address`       AS `post_address`,
         `c`.`website`            AS `website`,
         `c`.`staff_num`          AS `staff_num`,
         `c`.`gov`                AS `gov`,
         `c`.`artisan_num`        AS `artisan_num`,
         `c`.`rc_num`             AS `rc_num`,
         `d`.`time`               AS `time`,
         `d`.`end_time`           AS `end_time`,
         `d`.`type_fill`          AS `type_fill`
  from (((((`gfo_sa`.`datainformation` `d` left join `gfo_sa`.`company` `c` on ((`c`.`id` =
                                                                                 `d`.`company_id`))) left join `gfo_sa`.`category` `p1` on ((
    `d`.`crop_type` = `p1`.`id`))) left join `gfo_sa`.`category` `p2` on ((`d`.`type_category` =
                                                                           `p2`.`id`))) left join `gfo_sa`.`region` `r1` on ((
    `c`.`city` = `r1`.`id`))) left join `gfo_sa`.`region` `r2` on ((`c`.`area` = `r2`.`id`)))
  where ((`c`.`type` = 1) and (`d`.`type` = 1))
  order by `d`.`effective_time`;

